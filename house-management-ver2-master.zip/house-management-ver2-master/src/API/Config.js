const config = {
    HOST: "http://34.87.43.29:8080",
    WS: "http://34.87.43.29:8080/ws"
};
export default config;
