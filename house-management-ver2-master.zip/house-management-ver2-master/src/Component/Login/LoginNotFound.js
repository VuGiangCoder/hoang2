import {Component} from "react";

export class LoginNotFound extends Component {
    componentDidMount() {
        window.location.href = "/"
    }
    render() {
        return (
            <></>
        )
    }
}